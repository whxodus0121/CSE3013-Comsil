#include <stdio.h>

void dog();
void blackcow();

int main(void){

        dog();
        blackcow();
        return 0;
}
