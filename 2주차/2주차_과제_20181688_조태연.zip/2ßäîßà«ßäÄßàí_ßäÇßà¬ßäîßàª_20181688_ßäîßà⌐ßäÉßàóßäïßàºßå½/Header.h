#include <stdio.h>
#include <stdlib.h>

void count_num(int n,int num[]);
void print_count(int num[]);
