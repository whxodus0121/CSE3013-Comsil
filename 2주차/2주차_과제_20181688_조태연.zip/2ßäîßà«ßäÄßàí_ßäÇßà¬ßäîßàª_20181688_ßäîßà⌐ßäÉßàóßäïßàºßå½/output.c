#include "Header.h"

void print_count(int num[]){


        for(int i=0;i<10;i++){
                
                printf("%d ",num[i]);
        }
        printf("\n"); //완성된 num배열을 출력해주고 다음 입력칸과 구분하기 위한 줄바꿈
}
